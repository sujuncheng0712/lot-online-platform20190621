import React, { PureComponent } from 'react';
import { Card, Form, Col, Row } from 'antd';
import { connect } from 'dva';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './style.less';

class VendorProfile extends PureComponent {
  state = {
    width: '100%',
    orderData: [],
  };

  componentDidMount() {
    window.addEventListener('resize', this.resizeFooterToolbar);

    const { location: { search } } = this.props;
    fetch(`/api/products/${search.slice(5)}`, {
      method: 'GET',
    }).then((res) => {
      res.json().then((data) => {
        this.setState({
          orderData: data.data[0],
        });
      });
    });
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.resizeFooterToolbar);
  }

  resizeFooterToolbar = () => {
    const sider = document.querySelectorAll('.ant-layout-sider')[0];
    const width = `calc(100% - ${sider.style.width})`;
    if (this.state.width !== width) {
      this.setState({ width });
    }
  }

  render() {
    const { orderData } = this.state;
    const { location: { search } } = this.props;

    return (
      <PageHeaderLayout
        title="运营商详情"
        content="高级表单常见于一次性输入和提交大批量数据的场景。"
        wrapperClassName={styles.advancedForm}
      >
        <Card title="基本信息" className={styles.card} bordered={false}>
          <Row gutter={16}>
            <Col lg={6} md={12} sm={24}>
              <span>用户名: {orderData}</span>
            </Col>

            <Col xl={{ span: 6, offset: 2 }} lg={{ span: 8 }} md={{ span: 12 }} sm={24}>
              <span>商标: {}</span>
            </Col>
            <Col xl={{ span: 8, offset: 2 }} lg={{ span: 10 }} md={{ span: 24 }} sm={24}>
              <a href={`#/vendors/vendor-edit-password/${search}`}>修改密码</a>
            </Col>
          </Row>
        </Card>
      </PageHeaderLayout>
    );
  }
}

export default connect(({ global, loading }) => ({
  collapsed: global.collapsed,
  submitting: loading.effects['form/submitAdvancedForm'],
}))(Form.create()(VendorProfile));
