import React, {PureComponent} from 'react';
import {Card, Button, Form, Icon, Input, Popover} from 'antd';
import {connect} from 'dva';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './style.less';

// 输入框
const fieldLabels = {
  eid: '设备ID',
  area: '安装区域',
};

const formItemLayout = {
  labelCol: {
    xs: {span: 24},
    sm: {span: 4},
  },
  wrapperCol: {
    xs: {span: 24},
    sm: {span: 10},
  },
};

class Install extends PureComponent {
  constructor(...args) {
    super(...args);
    this.state = {};
  }

  componentDidMount() {

  }

  render() {
    const {form, submitting} = this.props;
    const {getFieldDecorator, validateFieldsAndScroll, getFieldsError} = form;
    const {location: {search}} = this.props;
    const ad = search.slice(1).split('=');

    // 请求服务器
    const validate = () => {
      validateFieldsAndScroll((error, values) => {
        if(!error){
          fetch(`http://iot.dochen.cn/api/orders/${ad[1]}/delivery`, {
            method: 'POST',
            body: JSON.stringify(values),
          }).then((res) => {
            if (res.ok) {
              res.json().then((info) => {
                if (info.status) {
                  location.href = `#/vendors/order-profile/${search}`;
                }
              });
            }
          });
        }
      });
    };

    const errors = getFieldsError();
    const getErrorInfo = () => {
      const errorCount = Object.keys(errors).filter(key => errors[key]).length;
      if (!errors || errorCount === 0) {
        return null;
      }
      const scrollToField = (fieldKey) => {
        const labelNode = document.querySelector(`label[for="${fieldKey}"]`);
        if (labelNode) {
          labelNode.scrollIntoView(true);
        }
      };
      const errorList = Object.keys(errors).map((key) => {
        if (!errors[key]) {
          return null;
        }
        return (
          <li key={key} className={styles.errorListItem} onClick={() => scrollToField(key)}>
            <Icon type="cross-circle-o" className={styles.errorIcon} />
            <div className={styles.errorMessage}>{errors[key][0]}</div>
            <div className={styles.errorField}>{fieldLabels[key]}</div>
          </li>
        );
      });
      return (
        <span className={styles.errorIcon} style={{float: 'right'}}>
          <Popover
            title="表单校验信息"
            content={errorList}
            overlayClassName={styles.errorPopover}
            trigger="click"
            getPopupContainer={trigger => trigger.parentNode}
          >
            <Icon type="exclamation-circle" />
          </Popover>
          {errorCount}
        </span>
      );
    };

    return (
      <PageHeaderLayout
        title="安装信息"
        wrapperClassName={styles.advancedForm}
      >
        <Card title="基本信息" className={styles.card} bordered={false}>
          <Form>
            <Form.Item label={fieldLabels.eid} {...formItemLayout} >
              {getFieldDecorator('eid', {
                // initialValue: this.state.priceValue,
                rules: [{required: true, message: '*'}],
              })(
                <Input placeholder="*" />
              )}
            </Form.Item>
            <Form.Item label={fieldLabels.area} {...formItemLayout} >
              {getFieldDecorator('area', {
                // initialValue: this.state.priceValue,
                rules: [{required: true, message: '*'}],
              })(
                <Input placeholder="*" />
              )}
            </Form.Item>
          </Form>
        </Card>
        <div style={{display: `flex`, alignItems: `center`, flexDirection: `row-reverse`}}>
          <Button type="primary" onClick={validate} loading={submitting}>提交</Button>
          {getErrorInfo()}
        </div>
      </PageHeaderLayout>
    );
  }
}

export default connect(({global, loading}) => ({
  collapsed: global.collapsed,
  submitting: loading.effects['form/submitAdvancedForm'],
}))(Form.create()(Install));
