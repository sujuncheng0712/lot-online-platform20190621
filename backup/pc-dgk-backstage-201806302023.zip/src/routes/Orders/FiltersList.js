import React, {PureComponent} from 'react';
import {Badge} from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';

const statusMap = ['default', 'warning', 'error', 'processing', 'success', 'default', 'processing', 'success'];
const status = ['已关闭', '待确认', '已拒绝', '待付款', '已付款', '待发货', '待收货', '已完成'];

class OrdersList extends PureComponent {
  constructor(...args) {
    super(...args);
    this.state = {
      lists: [],
    };
  }

  componentDidMount() {
    // fetch('http://iot.dochen.cn/api/orders').then((res) => {
    //   if (res.ok) {
    //     res.json().then((info) => {
    //       if (info.status) {
    //         this.setState({
    //           lists: info.data,
    //         });
    //       }
    //     });
    //   }
    // });
  }

  render() {
    const {lists} = this.state;

    return (
      <PageHeaderLayout title="耗材订单列表">
        <div style={{padding: 20, backgroundColor: '#fff'}}>
          <div style={styles.title}>
            <div style={styles.id}>序号</div>
            <div style={styles.consignee}>收货人</div>
            <div style={styles.phone}>联系电话</div>
            <div style={styles.address}>收货地址</div>
            <div style={styles.state}>订单状态</div>
            <div style={styles.pay_amount}>支付金额</div>
          </div>
          {
            lists.map((item) => (
              <div key={item.oid} style={styles.item}>
                <div style={styles.rowT}>
                  <div style={styles.oid}>订单编号：{item.oid}</div>
                  <div style={styles.created_at}>成交时间：{item.created_at}</div>
                </div>
                <div style={styles.row}>
                  <div style={styles.id}>{item.id}</div>
                  <div style={styles.consignee}>{item.consignee}</div>
                  <div style={styles.phone}>{item.phone}</div>
                  <div style={styles.address}>{item.address}</div>
                  <div style={styles.state}>
                    <Badge status={statusMap[item.state]} text={status[item.state]} />
                  </div>
                  <div span={4} style={styles.pay_amount}>
                    {
                      item.pay_amount !== null ? (
                        <span>{`￥${item.pay_amount}元`}</span>
                      ) : '--'
                    }
                  </div>
                </div>
              </div>
            ))
          }
        </div>
      </PageHeaderLayout>
    );
  }
}

const styles = {
  alignCenter: {
    textAlign: 'center',
  },
  title: {
    display: 'flex',
    backgroundColor: '#eee',
    padding: '10px 0px',
    marginBottom: 5,
  },
  item: {
    borderTop: '1px solid #ddd',
    paddingBottom: 15,
  },
  row: {
    display: 'flex',
    paddingTop: 15,
  },
  rowT: {
    display: 'flex',
    padding: '3px 0px',
    backgroundColor: '#f6f6f6',
  },
  oid: {
    padding: '0px 15px',
  },
  created_at: {
    padding: '0px 15px',
  },
  id: {
    width: 100,
    padding: '0px 10px',
    textAlign: 'center',
  },
  consignee: {
    width: 200,
    padding: '0px 10px',
    textAlign: 'center',
  },
  phone: {
    width: 250,
    padding: '0px 10px',
    textAlign: 'center',
  },
  address: {
    width: `${100 / 2  }vw`,
    padding: '0px 10px',
    textAlign: 'center',
  },
  rowAddress: {
    width: `${100 / 2  }vw`,
    padding: '0px 10px',
    textAlign: 'left',
  },
  state: {
    width: 200,
    padding: '0px 10px',
    textAlign: 'center',
  },
  pay_amount: {
    width: 200,
    padding: '0px 10px',
    textAlign: 'center',
  },
};

export default OrdersList;