import React, {PureComponent} from 'react';
import {Menu, Icon, Spin, Tag, Dropdown, Avatar, Divider} from 'antd';
import moment from 'moment';
import groupBy from 'lodash/groupBy';
import Debounce from 'lodash-decorators/debounce';
import {Link} from 'dva/router';
import NoticeIcon from '../NoticeIcon';
import HeaderSearch from '../HeaderSearch';
import styles from './index.less';

export default class GlobalHeader extends PureComponent {
  componentWillUnmount() {
    this.triggerResizeEvent.cancel();
  }

  getNoticeData() {
    const {notices = []} = this.props;
    if (notices.length === 0) {
      return {};
    }
    const newNotices = notices.map(notice => {
      const newNotice = {...notice};
      if (newNotice.datetime) {
        newNotice.datetime = moment(notice.datetime).fromNow();
      }
      // transform id to item key
      if (newNotice.id) {
        newNotice.key = newNotice.id;
      }
      if (newNotice.extra && newNotice.status) {
        const color = {
          todo: '',
          processing: 'blue',
          urgent: 'red',
          doing: 'gold',
        }[newNotice.status];
        newNotice.extra = (
          <Tag color={color} style={{marginRight: 0}}>
            {newNotice.extra}
          </Tag>
        );
      }
      return newNotice;
    });
    return groupBy(newNotices, 'type');
  }

  toggle = () => {
    const {collapsed, onCollapse} = this.props;
    onCollapse(!collapsed);
    this.triggerResizeEvent();
  };
  /* eslint-disable*/
  @Debounce(600)
  triggerResizeEvent() {
    const event = document.createEvent('HTMLEvents');
    event.initEvent('resize', true, false);
    window.dispatchEvent(event);
  }

  render() {
    const {currentUser, collapsed, fetchingNotices, isMobile, onNoticeVisibleChange, onMenuClick, onNoticeClear} = this.props;
    const menu = (
      <Menu className={styles.menu} selectedKeys={[]} onClick={onMenuClick}>
        <Menu.Item disabled>
          <Icon type="user"/>个人中心
        </Menu.Item>
        <Menu.Item>
          <Icon type="tool" />
          <a
            href={`#/vendors/reset-password/?role=${localStorage.getItem("antd-pro-authority")}&id=${JSON.parse(sessionStorage.getItem('dochen-auth')).uuid}`}
            style={{display:"inline"}}
          >
            重置密码
          </a>
        </Menu.Item>
        <Menu.Item disabled>
          <Icon type="setting"/>设置
        </Menu.Item>
        <Menu.Divider />
        <Menu.Item key="logout">
          <Icon type="logout"/>退出登录
        </Menu.Item>
      </Menu>
    );
    const noticeData = this.getNoticeData();
    return (
      <div className={styles.header}>
        {isMobile && [
          <Link to="/" className={styles.logo} key="logo">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAeCAYAAABkDeOuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGtmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAxOC0wNC0yMFQxNzo1Nzo1MCswODowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAxOC0wNC0yNFQwOTo0Mjo0MiswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMTgtMDQtMjRUMDk6NDI6NDIrMDg6MDAiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6YjMyZDkxMGEtMDdhZC02ZDQ5LTk2YmUtNDUzYzk1OTVkNGVjIiB4bXBNTTpEb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6ZmIxZTkzMjAtMTU3NS03YTQzLTkyMmItNTkyMzljMzhmMmNiIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6NmIzNzg4ZTktY2U2Yy01MTQ1LWFhOGUtZjdiZjc4MjRhNzMxIiBkYzpmb3JtYXQ9ImltYWdlL3BuZyIgcGhvdG9zaG9wOkNvbG9yTW9kZT0iMyIgcGhvdG9zaG9wOklDQ1Byb2ZpbGU9InNSR0IgSUVDNjE5NjYtMi4xIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo2YjM3ODhlOS1jZTZjLTUxNDUtYWE4ZS1mN2JmNzgyNGE3MzEiIHN0RXZ0OndoZW49IjIwMTgtMDQtMjBUMTc6NTc6NTArMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cykiLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjUzZDA2YmRkLTc3NWUtZDc0YS04YmVmLWFhNjZiMGRiY2VlOCIgc3RFdnQ6d2hlbj0iMjAxOC0wNC0yMFQxNzo1Nzo1MCswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6YjMyZDkxMGEtMDdhZC02ZDQ5LTk2YmUtNDUzYzk1OTVkNGVjIiBzdEV2dDp3aGVuPSIyMDE4LTA0LTI0VDA5OjQyOjQyKzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvGKUroAAA/HSURBVGiB7Zl7kFTVnce/59x3v3ume97NDMMAAxJ5I4JZFIQY3RWMZTQxRg1ml6iJj5i4cY370DKJjyVaAqLxWfiKEgtB1/K5IgQRhfAeZpgX856e6cd09+17u+89Z/+4zcA4goz7x9ZW+au6Vbe6773ndz73d36/7/ldwjnHN3ZmRv+vHfj/ZN/AGoOJX/wh2974lTcpJZWIvv0Som+/DO+MhWCGDm7nYaeGoFaOB7MtFJ+/HIRScGaPuJeIEpiZRWLnB8jH+2Fn0hA0F6x0YpyVjM83+zoncisXJpIMcPQp5dUNYPZ279nz+5XyauR6OyB6A/DNPR/cNCAVlwAgAAG4ZYFldYCQwmAExLZhZVOAKIEA4LYFQXEDogTB44XR2QLk81AqasByRuE2CilQhIH/3lxceum1g6eE1bvxiSsAzDsdLMHlIdnWBmalEkP60QNdVNV2i77gXsHtBRFFwMqfnjbnABUgevywEoNatr/j+nx8YIWVTs4DY34QApgGwDmyrYcGCBW2CS7PK3Ko/GUxUAxu5SH6ipDc+R6Srz0OKRgGOAdnrI7nzH8ahsU5WN6EZ+rcJ9WK6kZbTwEA1EgdCOeQi0qRObI32L/pmd/IZRECxgAQEIGSXH93hRgMvwDgzVPC6tqweiWA75x2rhaD6PVC9AVh9LSDKhoEl2evUla9Tq2sXQ8qgDMbhI5e5ZwxUEWD6PYicWDnyvSRPb+zM6kwEURQWQGhggOzYMw0QtzKr4h9/OaK7LHGOwLzl/3YM3XOISJKoC4Pel5eD9sARA8BgKkg5I6Tx2JZILLyFzsFzd1odDRDqaiGoLqglEaQadqvtD50++7UgYM1ggsApSBEQLYjD/dEX3zK6tfvOdn3UbDUyvEdpwP1RRM9foBz2Knk9FT/jsdz0c4rQksuv0QqCptWfBAgI0hBcPlACEVs65Z1iU/fXyUFQxC9gRGATjYiSiCSDKq5YXS0zO488uCB2jtWL0A+94nvW+egauWv0fX8Q1ArawHw9BdfDDMyENy+FKEUotsLrWYS5NIqGL0daLjzyp168+Eaz9TJ4JYFQimynS0ILZm9Y8rq1xeIgeIRvpxZgicE3LbAjCyYaYCZxshcRAioqkEqKkG2tWHJwPsbdzPTgFRcCiJKoLLqRJ8nALm4DB1/uv+x+La3VsnhClBFc0ARApYzYKWTzpKy8rBSCfB8rjBzDjEQguj2ka5nH9yaOrQrwG2GwLzFUMvGgZnZ0/rPsjrEohJ46mfByiRx6NZLt2fbGqa7xhdACSKMnnbIxWW7a259YIHo9sHoaP4asJgNqroguL0gggAqySCEwM4MwU4PAYTCybAMamUt9OZDU4+tv/cJ28jASsaQTwzCSsYgKBp6Nz5xae/rT9+kVFSDCMIwiHw8CtHtO+SfveguqrqWK6VV3w/MveA/QciQlYyBCCLAGaRgCGa0U+rd+ORaveUgbEOHUl59eliMgTMbvlnngVk5HP7F8v/Sjx5YoEbqwG0LAGD2dSIwf+mBOZub5gXmLQY4h1pePeIxo5bhl1ku1o/i81c8XH3zfavBbORi/ejf/JwvH4vOMjpbbs12NM1RwhXgjIMzG0pZBPFtb/5Uq6x5QC6tOkplFdr4KdDbG0nPa+s3iL4AiCgDnAGEwEoOwnf2uevd9TNWCS4fsu2NEDx+uOtnvuo9e8H9sa1vbEsf2VsvBULgtg05XInU/k9/kJm993bPWfN6lYpqpA5/dkr/bT0tuCfPgBQM4fDtl7+U2LXtIlftRIBzEEGE2d8Fzu3G4vOXz8407beNzqMAdV5keNmVY4NFBREsZ/RkjzV1BeYtgRQqB1XdXUqpcrj8yhtf6H75sfcTO95dLIfLHQdEGeDA0L5PbvLNXHib6CuC6PGj/8NN15hdbV6lonoYVC7aA9/M83bU/Xb9qoEPXkem4W/I9XUCnCE/0Av/3PMHixYtX6a3HD7GrRyIIIJKMqxsBpmm/VfKofJHuG2BivKX+s4Zg+DyJFx1Z+HovavWRd964yp3fR0ADkIpjK5W+OcsagvMXzqr5cHbctwyHf8LNmZYIARUUd168yGY3e0IzL8QsC3Y2QyUcCXKVqz8Xnr/zkGeMwQiKQBnoKoGayj2HWaaAACzvxPpw5//kCjKiYlYFgTNDd+MhT9ON+wBz+Ugev2ouuEuyMVlUMurIfqLoJREOnrdvqp0Y5MqBVzcEUyc9G9+Pht96wUoZRFIRWFw2x7tO+fcVTftyLF1/3pd78anVrkn1TpTogKM7jaI/qLu2jv+OEOpHJ/xTJ3tQCejH3PmsJxBIfmLYHS3IfbRZoi+IOTSKsQ+3gLB40+6Jpz1Qfrw7qWi5MCgsgI7PVSfj/UXC4o6mPz8I8nsbT9X9ASGK5+dzUCrnrhX8hcd1Zv2wTayKLn0WrjrpsGKDzoikXNQSYZ/zqIuNTIBgsvruAMOKilgho6hfX8FVV0gZGQKJoRA9BXl+jY/92e9af9itSICFOSMNRSHEq7oqP3nR+eokdpkPjEAz5TZcLTW/xYWUCj9HieZEgo7nQS3GTjnoIq2BwRLT3hKwe08YWZ2ImdsMNfXVcNMw0fEk4fkEDTPR/lYP7IdRxE4ZwlcE6bB7OuCqHkg+oocvUYI6u55crQ/jAGU4si//AgD7/wZStm4kf8TAoAr6YOfLRY0F45HPcvnwG0rP/Hfnprpn3vBoN5yEIRSMD09agjRF/yasACnhHsD0KOHkGncB0Fzg8gKrGSslyquk/wk4BywUvFQ5uh+5KLdJYTS4cQJAFSSwXJGu97WAFtPQy6pgpWMIdO4t27g3VfvprJ6Qth+IWpsPQ0tUrerdMVP1ninnYPYh5uG4Y321184d6KGCiJs2xLin7z7M/fkGfcx0zylzjvZxg4LANXcMHs7ENv6IaRiN7hlQfQGDNEbGC7FAApCTxBLl18PO5XQWh7+pSM/CsCo6kKur9PQWxtAZRVWYhAsm4HZ1VbT9/oL11KFgIjSl/qQG8iheNHC+uDCi9ZYqQSIqp35BAQBosdPO5/5w73auInbiy+8/MNsa4MjT05jXwsW09NQK2oQuvAiUNUFqmowe455jc5mR2QWjCgK8vEBM77jHXAjm6OKBkJOZE87k4J70tluLVIHO6uDqhq4o+l0pbwUVFFPOQGqRCEFwx1EKlSu0+QaEAJuWeB2HlRxOQVIUSG4vWhf89strgnTiqRgiZkf7BkR+aPGHBumggkCpFA5PGfNgat2KjxTZ0P0BSuYaQxfwjkHty14Js/ok0Nl4HY+SigdEe3ctkCoMFGpqIYUDIHbFng+B5bPuWwjA2boYIYOW0+BmcboJXamxhioqsWIILbZegpEEMAZg1xcCjPa7Wpfe88Wqmqgqtu5npATx0k2htGdWUpFJcg07EGmaS/kUDmUihqIniCsVOK8EQ9nNqismdTlaQRjkIIlLVR16Sd3JIgoIzfYuxSMDRcPrWYy5FBZsxaZ9KhWPelRpbz6ETlc+UelLPIX/lXdjC8xQinMvg4dlE6LrLzrLEIo7EyqsIWzoVXVIr7t7Qt7Xllzo1Ja5aQR2z5xjB0WB0AgFZchfXAXom+9CHAOs7cDWmQCuG3N0Jv2zz5e1gHANjIQvYF9SlkkLQZC8Eyba0rB8A4re6LiCIqK7LGjNRCkZRU/vAVm7zEM7f8EnvqZrZ7J029Rysbd4qmfdeuEOx+5zT3xWzvz8eiYQHHOYRtZBOYvuz584RU9JX9/jV76vRtuN3t7TqJJIJeUoXvD6jXJPR9PUMprRvXgxgSLc0AKhAfTBz9D36ZnQGQZankNBNWFoT0fV/dveX4LCMFxWUAoha2n4Rpfv0mL1Dl7QA5oNfUv8px5IrwFAVSUMPDeqxv0tiOqfvQgel99HB1P/Q4sb4CqLrgnTwczzUmJXR/+XnT7xgQLnIPlDATmLu7wz/47ZNubEPnJb1YHz1u6w+hsKfjFIbp94MzGsbX3vGOnExB9QXA+OgeeESzR40e6Yfe5fW88cwnVXJeIHv+leuvh61KHPnu8+6XHWvTmQ5XHG3AgBFZmCJKvCP65F6ylmhtgDHrzQcjh8uekolLd2XwTR+gWhWF0toSP/sc/HsjF+hcoZdVI798JgEKpqEZy99bLjtx9zed2ZoicHLlnaoRSWKm4LzfYh2zbEeRjfaj80e0Xi/4iZiVjjh5kNpTSCNJH9tV2PP37daIv6ID+wrI/s72hrMDoOHo1EcSrnbfAMfS37U6L1uUBESVnrRMCnjNhpYYw8e61Py/5h+viVioBKRBC9lgjtJp6mxByTdtj/75RU10goghu2xC9ATA9PWFo99btxrGmAxy8JdvWIOotB6fl+rvHEVEEVT2w9ZRTbckp9iOnm4MowcoMIdvZDPeUmYmqa3/1/dbVd76mur0ghIIzBrWyGtG3XljlnTJrU2jZFW9n25vGDoszBqq6hs8BQHB5TrqAnwCVSUGL1D6daTn8WOvqXyE32AvfzG8jMPcC2HoapZfd8Bejp/3xvk3PrlIrawqtFw6qeQDOkIt2TyOiNM0acvKG4PY6/a18HkpZpN8ains4Y65RTn4lLcHZeXDAGkqgdMXKjamDu14ZeOe1K13jJ4PbFqgkQ/QG0PHsHza5J00PyuFKfcQjRpPhTn0/5cFwvDKiIA/sbAb5eBTctuyyy396h3vi2SuPrXsAXRtWo+OJDdCb9kMbNxGC2wuquTH+tod+Flp82Rqzr3O4MgG80ER0OQ1DRR3WXfl4FGKgeKN/3pLpHJCYlT/uzwn/nYpKTuE3ATi4bcNOJUBF5wXV3vbgVa4JUwbN/q7h6igGimElYnLb2nveycf6RqAZFVlWOhkglBbk//FwL5wXvqAcF6Isb4JKiqGUhPbL4YpNUnHZM/7pC7qj770GOeiGFCoD0ArB48PxCVqpBAizEf7uD24W/cG/Du3Zfl8+OTgeIBA0VwEccfRWLgtCRRQvuXyNUha5WW89BG5Zkj0Uh5VKgZnZIkcz2bCNDKgkK5zzwn6SgjEb3NTBrLzC7TwIIcjHo8j1d4OI/VAra1F13a8vbr7/xp35eLTQ5nG2c/GPty3Uqv70sG/Wt395SljlV910j61nnixUCg5CnE9atg0wBjlUTpK7PyKZ5oN6YN7iAUF1d0nFZQmqqDB7O5wIs6xTCsjjG9Z8PArPtHkvKqWRF9MNu5fbqeTFucTAJMJ5kHNuC75gt1RU8il1e1/xz17UyJkNZhqQQ5ULiCQFYFuQwxU9uWg3lFAFKq76OZiR/YSIwncFtx8sb3IQECsZg6d+5mee+lmwUkmAM1h6GjxnINN8EO5J0z+tuPrWeVZyMCR6AwyUEnDOOWM0H4+qI3z/5vP9mds3X6THYN/AGoP9D2mng1n+wKjvAAAAAElFTkSuQmCC" alt="logo" width="32"/>
          </Link>,
          <Divider type="vertical" key="line"/>,
        ]}
        <Icon
          className={styles.trigger}
          type={collapsed ? 'menu-unfold' : 'menu-fold'}
          onClick={this.toggle}
        />
        <div className={styles.right}>
          <HeaderSearch
            className={`${styles.action} ${styles.search}`}
            placeholder="站内搜索"
            dataSource={['搜索提示一', '搜索提示二', '搜索提示三']}
            onSearch={value => {
              console.log('input', value); // eslint-disable-line
            }}
            onPressEnter={value => {
              console.log('enter', value); // eslint-disable-line
            }}
          />
          <NoticeIcon
            className={styles.action}
            // count={currentUser.notifyCount}
            onItemClick={(item, tabProps) => {
              console.log(item, tabProps); // eslint-disable-line
            }}
            onClear={onNoticeClear}
            onPopupVisibleChange={onNoticeVisibleChange}
            loading={fetchingNotices}
            popupAlign={{offset: [20, -16]}}
          >
            <NoticeIcon.Tab
              list={noticeData['通知']}
              title="通知"
              emptyText="你已查看所有通知"
              emptyImage="https://gw.alipayobjects.com/zos/rmsportal/wAhyIChODzsoKIOBHcBk.svg"
            />
            <NoticeIcon.Tab
              list={noticeData['消息']}
              title="消息"
              emptyText="您已读完所有消息"
              emptyImage="https://gw.alipayobjects.com/zos/rmsportal/sAuJeJzSKbUmHfBQRzmZ.svg"
            />
            <NoticeIcon.Tab
              list={noticeData['待办']}
              title="待办"
              emptyText="你已完成所有待办"
              emptyImage="https://gw.alipayobjects.com/zos/rmsportal/HsIsxMZiWKrNUavQUXqx.svg"
            />
          </NoticeIcon>
          {currentUser.name ? (
            <Dropdown overlay={menu}>
              <span className={`${styles.action} ${styles.account}`}>
                <Avatar size="small" className={styles.avatar} src={currentUser.avatar}/>
                <span className={styles.name}>{currentUser.name}</span>
              </span>
            </Dropdown>
          ) : (
            <Spin size="small" style={{marginLeft: 8}}/>
          )}
        </div>
      </div>
    );
  }
}
