/* eslint-disable linebreak-style */
// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less
module.exports = {
  'primary-color': '#ff8800',
  'card-actions-background': '#f5f8fa',
};
