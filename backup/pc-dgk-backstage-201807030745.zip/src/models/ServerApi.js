const url = 'http://iot.dochen.cn/api';
// const url = '/api';

export {url};